"""
House Price Prediction
=======================
Predicts house sale prices using the Ames Housing dataset
(Kaggle: House Prices - Advanced Regression Techniques).

Pipeline:
  1. Load train.csv and test.csv
  2. Clean missing values
  3. Encode categorical columns (ordinal + one-hot)
  4. Train a Gradient Boosting model
  5. Evaluate on a held-out validation split
  6. Predict on test.csv and save submission.csv

Usage:
    python house_price_prediction.py
Expects train.csv and test.csv in the same folder as this script.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

RANDOM_STATE = 42

# ----------------------------------------------------------------------
# 1. LOAD DATA
# ----------------------------------------------------------------------
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")

train_ids = train["Id"]
test_ids = test["Id"]
y = train["SalePrice"]

# Combine train + test so cleaning/encoding stay perfectly consistent
# between the two (e.g. one-hot encoding produces identical columns).
train_features = train.drop(columns=["SalePrice"])
combined = pd.concat([train_features, test], axis=0, ignore_index=True)

# ----------------------------------------------------------------------
# 2. CLEAN MISSING VALUES
# ----------------------------------------------------------------------
# These columns are blank when the feature simply doesn't exist on the
# house (no pool, no alley, no garage, etc.) -> fill with "None"
none_cols = ["PoolQC", "MiscFeature", "Alley", "Fence", "FireplaceQu", "GarageType",
             "GarageFinish", "GarageQual", "GarageCond", "BsmtExposure", "BsmtFinType2",
             "BsmtQual", "BsmtCond", "BsmtFinType1", "MasVnrType"]
for col in none_cols:
    combined[col] = combined[col].fillna("None")

# These are numeric "doesn't exist" cases -> fill with 0
zero_cols = ["GarageYrBlt", "MasVnrArea", "BsmtFinSF1", "BsmtFinSF2", "BsmtUnfSF",
             "TotalBsmtSF", "BsmtFullBath", "BsmtHalfBath", "GarageCars", "GarageArea"]
for col in zero_cols:
    combined[col] = combined[col].fillna(0)

# LotFrontage: fill with the median for that neighborhood
combined["LotFrontage"] = combined.groupby("Neighborhood")["LotFrontage"].transform(
    lambda x: x.fillna(x.median())
)

# A handful of remaining columns: fill with the most common value
for col in ["Electrical", "MSZoning", "Utilities", "Functional", "SaleType",
            "Exterior1st", "Exterior2nd", "KitchenQual"]:
    combined[col] = combined[col].fillna(combined[col].mode()[0])

assert combined.isnull().sum().sum() == 0, "Still missing values after cleaning!"

# ----------------------------------------------------------------------
# 3. ENCODE CATEGORICAL COLUMNS
# ----------------------------------------------------------------------
# Ordinal encoding for columns with a natural order (quality/condition ratings)
quality_map = {"None": 0, "Po": 1, "Fa": 2, "TA": 3, "Gd": 4, "Ex": 5}
qual_cols = ["ExterQual", "ExterCond", "BsmtQual", "BsmtCond", "HeatingQC",
             "KitchenQual", "FireplaceQu", "GarageQual", "GarageCond", "PoolQC"]
for col in qual_cols:
    combined[col] = combined[col].map(quality_map)

combined["BsmtExposure"] = combined["BsmtExposure"].map({"None": 0, "No": 1, "Mn": 2, "Av": 3, "Gd": 4})
combined["GarageFinish"] = combined["GarageFinish"].map({"None": 0, "Unf": 1, "RFn": 2, "Fin": 3})
combined["LotShape"] = combined["LotShape"].map({"IR3": 0, "IR2": 1, "IR1": 2, "Reg": 3})

# One-hot encoding for columns with no natural order
nominal_cols = combined.select_dtypes(include="object").columns.tolist()
combined = pd.get_dummies(combined, columns=nominal_cols, drop_first=True)

# Split back into train/test now that encoding is done and columns match
X = combined.iloc[: len(train)].drop(columns=["Id"])
X_submit = combined.iloc[len(train):].drop(columns=["Id"])

# ----------------------------------------------------------------------
# 4. TRAIN / VALIDATE
# ----------------------------------------------------------------------
X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE
)

model = GradientBoostingRegressor(
    n_estimators=500, learning_rate=0.05, max_depth=3, random_state=RANDOM_STATE
)
model.fit(X_train, y_train)

val_preds = model.predict(X_val)
mae = mean_absolute_error(y_val, val_preds)
rmse = np.sqrt(mean_squared_error(y_val, val_preds))
r2 = r2_score(y_val, val_preds)

print("=== Validation performance (Gradient Boosting) ===")
print(f"MAE:  ${mae:,.0f}")
print(f"RMSE: ${rmse:,.0f}")
print(f"R2:   {r2:.3f}")

# Top features
importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)
print("\nTop 10 most important features:")
print(importances.head(10))

# ----------------------------------------------------------------------
# 5. RETRAIN ON *ALL* TRAINING DATA, THEN PREDICT ON test.csv
# ----------------------------------------------------------------------
# Using every available labeled house (not just the 80% split) gives the
# final model the most information possible before predicting on new houses.
final_model = GradientBoostingRegressor(
    n_estimators=500, learning_rate=0.05, max_depth=3, random_state=RANDOM_STATE
)
final_model.fit(X, y)

test_preds = final_model.predict(X_submit)

submission = pd.DataFrame({"Id": test_ids, "SalePrice": test_preds})
submission.to_csv("submission.csv", index=False)
print("\nSaved predictions for test.csv to submission.csv")
