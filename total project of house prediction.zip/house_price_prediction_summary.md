# House Price Prediction — Project Summary

## Goal
Predict house sale prices from property features (size, quality, location, etc.)
using the Ames Housing dataset (Kaggle: *House Prices - Advanced Regression Techniques*).

## Dataset
- 1,460 labeled houses (training set) + 1,459 unlabeled houses (test set)
- 80 features per house: size, quality ratings, neighborhood, year built, garage, basement, etc.
- Target: `SalePrice` (ranged $34,900–$755,000, average ~$181,000)

## Pipeline

**1. Data cleaning**
Missing values were mostly *not* errors — they meant "this feature doesn't apply"
(e.g. blank `PoolQC` = no pool). Filled with `"None"`/`0` accordingly.
`LotFrontage` was filled using the median for each neighborhood rather than a
global average, since lot sizes vary a lot by area.

**2. Encoding categorical features**
- **Ordinal encoding** for ordered categories (e.g. quality ratings Poor→Excellent
  mapped to 0–5), since order carries information.
- **One-hot encoding** for unordered categories (e.g. `Neighborhood`), turning
  each category into its own 0/1 column.
- Train and test sets were combined *before* encoding to guarantee identical
  columns in both — avoids a common bug where train/test end up with
  mismatched features.

**3. Modeling — three approaches compared**

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression (baseline) | $21,961 | $52,272 | 0.644 |
| Random Forest (300 trees) | $17,228 | $28,505 | 0.894 |
| **Gradient Boosting (500 trees, final model)** | **$16,097** | **$26,038** | **0.912** |

- **Linear Regression**: fits a straight-line relationship; struggled with the
  large number of features and the skewed price distribution.
- **Random Forest**: many decision trees trained on random subsets of data,
  predictions averaged together. Cancels out individual trees' errors.
- **Gradient Boosting**: trees trained sequentially, each one correcting the
  errors left by the trees before it. Won out with the best accuracy.

**4. Most important features** (Gradient Boosting)
1. `OverallQual` — overall material/finish quality (by far the biggest driver)
2. `GrLivArea` — above-ground living area (square footage)
3. `GarageCars`, `TotalBsmtSF`, `BsmtFinSF1`, `1stFlrSF`, `2ndFlrSF`
4. `KitchenQual`, `ExterQual`, `LotArea`

This matches real-world intuition (quality and size drive price), which is a
good sanity check that the model learned genuine patterns rather than noise.

## Final result
- Final model: Gradient Boosting Regressor (`n_estimators=500`, `learning_rate=0.05`, `max_depth=3`)
- Validation performance: **R² = 0.912**, average error ≈ **$16,000**
- Predictions generated for the 1,459 test houses and saved to `submission.csv`

## Key lessons learned
- "Missing" data often isn't broken data — understand *why* it's missing before deciding how to handle it.
- CSV round-trips can silently reintroduce missing values (pandas treats the literal text "None" as NaN by default when re-reading a file).
- Combine train and test data before one-hot encoding to keep columns consistent.
- Always validate on data the model hasn't seen — never judge a model using its own training data.
- Tree-based ensemble methods (Random Forest, Gradient Boosting) handle mixed numeric/categorical data and skewed targets much better than plain linear models.

## Possible next steps (not yet done)
- Cross-validation instead of a single train/test split (more reliable performance estimate)
- Log-transform `SalePrice` to reduce the effect of its right skew
- Hyperparameter tuning (e.g. `GridSearchCV`)
- Feature engineering, e.g. `TotalSF = 1stFlrSF + 2ndFlrSF + TotalBsmtSF`

## Deliverables
- `house_price_prediction.py` — full end-to-end pipeline (clean → encode → train → predict)
- `submission.csv` — predicted prices for the test set
